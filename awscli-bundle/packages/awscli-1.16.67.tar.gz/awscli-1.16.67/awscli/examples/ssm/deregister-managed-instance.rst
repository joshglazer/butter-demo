**To deregister a managed instance**

This example deregisters a managed instance. There is no output if the command succeeds.

Command::

  aws ssm deregister-managed-instance --instance-id "mi-08ab247cdf1046573"
