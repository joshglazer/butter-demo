**To cancel a stack update that is in progress**

The following ``cancel-update-stack`` command cancels a stack update on the ``myteststack`` stack::

  aws cloudformation cancel-update-stack --stack-name myteststack
